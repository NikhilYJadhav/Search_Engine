Drop Table details;
CREATE TABLE Details (
    organization VARCHAR(255),
    country VARCHAR(255),
    Region VARCHAR(255),
    founding_year INT,
    services VARCHAR(255),
    industry VARCHAR(255)
);

INSERT INTO Details (organization, country, Region, founding_year, services) VALUES
('Startupbootcamp', 'United Kingdom', 'London', 2010, 'Software, Financial Services, IT'),
('Entrepreneur First', 'United Kingdom', 'London', 2011, 'AI, Software, ML'),
('Bethnal Green Ventures', 'United Kingdom', 'London', 2012, 'Healthcare, Software, Education'),
('Techstars London', 'United Kingdom', 'London', 2006, 'Software, AI, IT'),
('Founders Factory', 'United Kingdom', 'London', 2015, 'Software, AI, IT'),
('London Co-Investment Fund', 'United Kingdom', 'London', 2014, 'Software, AI, Healthcare'),
('Upscale', 'United Kingdom', 'London', 2011, 'Software, SaaS, E-Commerce'),
('Outlier Ventures', 'United Kingdom', 'London', 2014, 'Software, Blockchain, IT'),
('Collider', 'United Kingdom', 'London', 2012, 'Advertising, Analytics, Software'),
('Pario Ventures', 'United Kingdom', 'London', 2010, 'Automotive, Fintech, Software'),
('Pi Ventures', 'United Kingdom', 'London', 2015, 'Software, Real Estate, SaaS'),
('CyLon', 'United Kingdom', 'London', 2015, 'Cyber Security, Software'),
('Data Pitch', 'United Kingdom', 'London', 2017, 'Software, IT, Analytics'),
('Chivas Ventures', 'United Kingdom', 'London', 2014, 'Food & Beverage, Fashion, Manufacturing'),
('Tech Nation', 'United Kingdom', 'London', 2010, 'Fintech, Financial Services, IT'),
('Breed Reply', 'United Kingdom', 'London', 2014, 'Software, IT, IoT'),
('iStarter', 'United Kingdom', 'London', 2012, 'E-Commerce, IT, Healthcare'),
('L Marks', 'United Kingdom', 'London', 2012, 'Software, IT, Apps'),
('Insurtech Gateway', 'United Kingdom', 'London', 2016, 'Insurance, Insurtech, Financial Services'),
('Ignite', 'United Kingdom', 'Newcastle', 2011, 'Software, SaaS, Travel'),
('CodeBase', 'United Kingdom', 'Edinburgh', 2014, 'Software, IT, Education'),
('DigitalHealth.London', 'United Kingdom', 'London', 2016, 'Healthcare, Medical, IT'),
('Geovation', 'United Kingdom', 'London', 2009, 'Real Estate, Software'),
('Oxygen Accelerator', 'United Kingdom', 'Birmingham', 2011, 'E-Commerce, Internet, Mobile'),
('Huckletree', 'United Kingdom', 'London', 2014, 'E-Commerce, Software, Mobile Apps'),
('Carbon Trust', 'United Kingdom', 'London', 2001, 'Energy, Manufacturing, Chemical'),
('Startup Campus', 'United Kingdom', 'London', 2015, 'Software, Healthcare, Mobile Apps'),
('Potential VC', 'United Kingdom', 'London', 2015, 'E-Commerce, Apps, Software'),
('ChangeLabs', 'United Kingdom', 'London', 2018, 'Electric Vehicles, Education, E-Commerce');

INSERT INTO Details (organization, country, Region, founding_year, services) VALUES
('Bytedance', 'China', 'Beijing', 2017, 'Artificial intelligence'),
('SpaceX', 'United States', 'Hawthorne', 2012, 'Other'),
('Stripe', 'United States', 'San Francisco', 2014, 'Fintech'),
('Klarna', 'Sweden', 'Stockholm', 2011, 'Fintech'),
('Canva', 'Australia', 'Surry Hills', 2018, 'Internet software & services'),
('Instacart', 'United States', 'San Francisco', 2014, 'Supply chain, logistics, & delivery'),
('Databricks', 'United States', 'San Francisco', 2019, 'Data management & analytics'),
('Revolut', 'United Kingdom', 'London', 2018, 'Fintech'),
('Nubank', 'Brazil', 'Sao Paulo', 2018, 'Fintech'),
('Epic Games', 'United States', 'Cary', 2018, 'Other');

SELECT * FROM Details;

SELECT * FROM Details WHERE Region = 'London';

SELECT * FROM Details WHERE founding_year > 2015;

SELECT * FROM Details WHERE industry = 'Fintech';

SELECT country, COUNT(*) AS num_organizations FROM Details GROUP BY country;

SELECT country, COUNT(*) AS num_organizations FROM Details GROUP BY country;

SELECT * FROM Details WHERE services LIKE '%Software%';

SELECT * FROM Details WHERE country = 'United Kingdom' AND founding_year < 2010;

SELECT * FROM Details WHERE Region = 'London' AND services LIKE '%E-Commerce%';

SELECT founding_year, country, Region, GROUP_CONCAT(organization) AS organizations
FROM Details
GROUP BY founding_year, country, Region
ORDER BY founding_year, country, Region;

SELECT services, GROUP_CONCAT(organization) AS startups
FROM Details
GROUP BY services;
