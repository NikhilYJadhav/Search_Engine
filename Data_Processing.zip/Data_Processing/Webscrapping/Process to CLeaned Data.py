#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import seaborn as sns
import os


# In[2]:


df=pd.read_csv("dataset.csv")


# In[3]:


df


# In[4]:


df.isnull().sum()


# In[5]:


missing_value=["N/a","na",np.nan]
df=pd.read_csv("dataset.csv",na_values=missing_value)


# In[6]:


df.isnull().sum()


# In[23]:


df.drop(columns=df.columns[5], axis=1, inplace=True)


# In[25]:


df.drop(columns=df.columns[5], axis=1, inplace=True)
df


# In[7]:


sns.heatmap(df.isnull(),yticklabels=False)


# In[8]:


df.dropna(how='all')


# In[9]:


# dfll = pd.DataFrame(data={
#     "Founding Date":[1,np.nan,3,2,3]
# })


# In[10]:


df.fillna(method="ffill")


# In[11]:


df.head(100)


# In[26]:


df.info('Founding Date')


# In[27]:


df["Founding Date"]=pd.to_datetime(df["Founding Date"])
df["Founding Date"]


# In[28]:


df["Founding Date"].dt.year


# In[29]:


df


# In[16]:


df.head(100)


# In[17]:


df["Founding Date"].fillna(0)


# In[30]:


df.head(100)


# In[33]:


df.rename( columns={'column:0':'ID'}, inplace=True)


# In[35]:


df 


# In[39]:


df.dropna()


# In[40]:


df.to_csv


# In[41]:


df.to_csv('cleaned.csv')


# In[ ]:




